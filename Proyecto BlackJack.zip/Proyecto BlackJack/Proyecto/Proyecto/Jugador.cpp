#include "Jugador.h"
// ========== CONSTRUCTOR =========== //
Jugador :: Jugador(string nickname, Mano* man) : JugadorGenerico(nickname, man) {}
Jugador :: ~Jugador() {}
