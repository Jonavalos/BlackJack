#include "Juego.h"
#include "Jugador.h"

/*

PROYECTO PROGRAMACION 1
ESTUDIANTES:
BENJAMIN SOLANO
JONATHAN AVALOS

*/


int main() {

	Juego* jugar = new Juego();


	jugar;


	delete jugar;
	system("pause");
	return 0;
}