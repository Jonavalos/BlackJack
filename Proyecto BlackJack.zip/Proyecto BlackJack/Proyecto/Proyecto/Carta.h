/*

PROYECTO PROGRAMACION 1
ESTUDIANTES:
BENJAMIN SOLANO
JONATHAN AVALOS

*/

#pragma once
#include<iostream>
#include<sstream>
#include <fstream>
#include <string>
using namespace std;

#define DELIMITA_CAMPO ','
#define DELIMITA_REGISTRO '\n'

class Carta {
private:
	string valor;
	string palo;
	bool bocaAbajo;
public:
	Carta();
	Carta(string, string, bool);
	Carta(Carta* car);
	~Carta();

	void setValor(string val);
	void setPalo(string pal);
	void setBocaAbajo(bool boca);

	string getValor();
	string getPalo();
	bool getBocaAbajo();
	
	virtual void guardar(ostream& salida);
	
	static Carta* recuperar(fstream& strm);
	string toString();
};