#include "Dealer.h"
// Consrtuctor y destructor del dealer...
Dealer::Dealer(string nickname, Mano* man) : JugadorGenerico(nickname,man){}
Dealer :: ~Dealer(){ }
void Dealer :: volteaSegunda(){  }

